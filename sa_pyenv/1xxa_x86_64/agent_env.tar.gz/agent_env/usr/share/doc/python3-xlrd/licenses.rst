Licenses
========

.. literalinclude:: ../LICENSE
