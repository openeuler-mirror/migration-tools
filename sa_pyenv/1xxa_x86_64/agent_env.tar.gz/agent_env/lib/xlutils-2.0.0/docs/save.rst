xlutils.save
============

This allows serialisation of :class:`xlrd.Book` objects back into binary Excel files.

Here's a simple example:

>>> import os
>>> from xlrd import open_workbook
>>> from xlutils.save import save
>>> wb = open_workbook(os.path.join(test_files,'testall.xls'))
>>> os.listdir(temp_dir)
[]
>>> save(wb,os.path.join(temp_dir,'saved.xls'))
>>> os.listdir(temp_dir)
['saved.xls']

You can also save the data to a stream that you provide:

>>> from xlutils.compat import BytesIO
>>> s = BytesIO()
>>> save(wb,s)
>>> len(s.getvalue())
5632
